export default [
  require("D:\\wamp64\\www\\documentation\\APIUBL2.1\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("D:\\wamp64\\www\\documentation\\APIUBL2.1\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("D:\\wamp64\\www\\documentation\\APIUBL2.1\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("D:\\wamp64\\www\\documentation\\APIUBL2.1\\src\\css\\custom.css"),
];
