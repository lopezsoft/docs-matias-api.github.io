import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/docs-matias-api.github.io/blog',
    component: ComponentCreator('/docs-matias-api.github.io/blog', '3c8'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/archive',
    component: ComponentCreator('/docs-matias-api.github.io/blog/archive', 'd3b'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/authors',
    component: ComponentCreator('/docs-matias-api.github.io/blog/authors', 'af7'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/first-blog-post',
    component: ComponentCreator('/docs-matias-api.github.io/blog/first-blog-post', 'e80'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/long-blog-post',
    component: ComponentCreator('/docs-matias-api.github.io/blog/long-blog-post', '106'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/mdx-blog-post',
    component: ComponentCreator('/docs-matias-api.github.io/blog/mdx-blog-post', '6b3'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/tags',
    component: ComponentCreator('/docs-matias-api.github.io/blog/tags', '627'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/tags/docusaurus',
    component: ComponentCreator('/docs-matias-api.github.io/blog/tags/docusaurus', 'bb8'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/tags/facebook',
    component: ComponentCreator('/docs-matias-api.github.io/blog/tags/facebook', 'a3e'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/tags/hello',
    component: ComponentCreator('/docs-matias-api.github.io/blog/tags/hello', '16b'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/tags/hola',
    component: ComponentCreator('/docs-matias-api.github.io/blog/tags/hola', '41e'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/blog/welcome',
    component: ComponentCreator('/docs-matias-api.github.io/blog/welcome', 'c3c'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/markdown-page',
    component: ComponentCreator('/docs-matias-api.github.io/markdown-page', 'f10'),
    exact: true
  },
  {
    path: '/docs-matias-api.github.io/docs',
    component: ComponentCreator('/docs-matias-api.github.io/docs', '422'),
    routes: [
      {
        path: '/docs-matias-api.github.io/docs',
        component: ComponentCreator('/docs-matias-api.github.io/docs', 'c59'),
        routes: [
          {
            path: '/docs-matias-api.github.io/docs',
            component: ComponentCreator('/docs-matias-api.github.io/docs', '5b2'),
            routes: [
              {
                path: '/docs-matias-api.github.io/docs/billing-fields',
                component: ComponentCreator('/docs-matias-api.github.io/docs/billing-fields', 'dad'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/category/jsons-facturación',
                component: ComponentCreator('/docs-matias-api.github.io/docs/category/jsons-facturación', '163'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/category/jsons-nómina',
                component: ComponentCreator('/docs-matias-api.github.io/docs/category/jsons-nómina', '6f5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/endpoints',
                component: ComponentCreator('/docs-matias-api.github.io/docs/endpoints', 'bcf'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/intro',
                component: ComponentCreator('/docs-matias-api.github.io/docs/intro', '61f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/adjustment-note',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/adjustment-note', 'c43'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/AIU-invoice',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/AIU-invoice', '848'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/credit-invoice',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/credit-invoice', '844'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/credit-note',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/credit-note', '767'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/debit-note',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/debit-note', '964'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/EURO-invoice',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/EURO-invoice', '79e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice', '014'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice-final-consumer',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice-final-consumer', '4f0'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice-with-charges',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice-with-charges', 'd9b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice-with-discount',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice-with-discount', '234'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice-with-retentions-example',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice-with-retentions-example', 'c70'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/invoice-with-tip',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/invoice-with-tip', '7e4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/pos',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/pos', '2f4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/pos-credit-note',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/pos-credit-note', 'ed3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/pos-debit-note',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/pos-debit-note', '40c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/pos-final-consumer',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/pos-final-consumer', 'c1c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/pos-with-discount',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/pos-with-discount', 'c5d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/support-document',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/support-document', 'b23'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/USD-invoice',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/USD-invoice', 'd5a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/jsons-billing/USD-invoice-exportation',
                component: ComponentCreator('/docs-matias-api.github.io/docs/jsons-billing/USD-invoice-exportation', '8a0'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/payroll/payroll-delete',
                component: ComponentCreator('/docs-matias-api.github.io/docs/payroll/payroll-delete', 'e80'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/payroll/payroll-fields',
                component: ComponentCreator('/docs-matias-api.github.io/docs/payroll/payroll-fields', 'ca7'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/payroll/payroll-replace',
                component: ComponentCreator('/docs-matias-api.github.io/docs/payroll/payroll-replace', '861'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs-matias-api.github.io/docs/response-json',
                component: ComponentCreator('/docs-matias-api.github.io/docs/response-json', 'd45'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/docs-matias-api.github.io/',
    component: ComponentCreator('/docs-matias-api.github.io/', 'c3f'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
