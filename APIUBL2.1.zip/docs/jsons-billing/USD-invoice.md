---
sidebar_position: 7
---
# JSON de una Factura en USD

A continuación se muestra un ejemplo de un JSON que representa una factura en dólares. Este JSON se puede utilizar para pruebas o para simular una factura real.

```json title="invoice_usd.json"
{
  "resolution_number": "18764055792775",
  "date": "2024-05-10",
  "time": "17:49:45",
  "document_number": "10003",
  "operation_type_id": 1,
  "type_document_id": 7,
  "payments": [
    {
      "payment_method_id": 1,
      "means_payment_id": 42,
      "value_paid": "597.00"
    }
  ],
  "payment_exchange_rate": {
    "exchange_rate": "3800.00",
    "base_rate": "3800.00",
    "rate_date": "2024-05-09",
    "currency_id": 188
  },
  "lines": [
    {
      "invoiced_quantity": "3.00",
      "quantity_units_id": "1093",
      "um": "UNI",
      "line_extension_amount": "597.00",
      "free_of_charge_indicator": false,
      "description": "HONORARIOS REPRESENTACION LEGAL ECUADOR",
      "code": "999-001",
      "type_item_identifications_id": "4",
      "reference_price_id": "1",
      "price_amount": "312.43",
      "base_quantity": 3.00,
      "tax_totals": [
        {
          "tax_id": "1",
          "tax_amount": 113.4300,
          "taxable_amount": 597.00,
          "percent": 19
        }
      ]
    }
  ],
  "customer": {
    "country_id": "239",
    "city_id": "149",
    "identity_document_id": "10",
    "type_organization_id": 1,
    "tax_regime_id": 1,
    "tax_level_id": "5",
    "company_name": "COVINOS, INC",
    "dni": "444444017",
    "email": "flor.leyva@yorcorp.com",
    "address": "3843 S.BRISTOL ST 268 SANTA ANA"
  },
  "legal_monetary_totals": {
    "line_extension_amount": "597.00",
    "tax_exclusive_amount": "597.00",
    "tax_inclusive_amount": "710.43",
    "payable_amount": 710.43
  },
  "tax_totals": [{
    "tax_id": 1,
    "tax_amount": "113.43",
    "taxable_amount": "597.00",
    "percent": 19.0
  }]
}
```

