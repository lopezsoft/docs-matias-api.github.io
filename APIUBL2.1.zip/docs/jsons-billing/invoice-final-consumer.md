---
sidebar_position: 2.1
---

# JSON de una Factura consumidor final

A continuación se muestra un ejemplo de un JSON que representa una factura para consumidor final, **Solo se omite el objeto customer**. 
Este JSON se puede utilizar para pruebas o para simular una factura real.

```json title="invoice.json"
{
  "resolution_number": "18764071164948",
  "prefix": "FVP",
  "document_number": "6",
  "operation_type_id": 1,
  "type_document_id": 7,
  "graphic_representation": 0,
  "send_email": 0,
  "payments": [
    {
      "payment_method_id": 1,
      "value_paid": "19000.00",
      "means_payment_id": 10
    }
  ],
  "legal_monetary_totals": {
    "tax_inclusive_amount": "19000.0",
    "line_extension_amount": "17592.59",
    "tax_exclusive_amount": "17592.59",
    "payable_amount": 19000
  },
  "tax_totals": [
    {
      "tax_amount": 1407.41,
      "taxable_amount": 17592.59,
      "percent": 8,
      "tax_id": "4"
    }
  ],
  "lines": [
    {
      "base_quantity": "1.00",
      "code": "9",
      "free_of_charge_indicator": false,
      "tax_totals": [
        {
          "tax_amount": 1407.41,
          "taxable_amount": 17592.59,
          "percent": 8,
          "tax_id": "4"
        }
      ],
      "quantity_units_id": "1093",
      "line_extension_amount": "17592.59",
      "type_item_identifications_id": "4",
      "description": "Pizza PZ",
      "price_amount": "19000.00",
      "reference_price_id": "1",
      "invoiced_quantity": 1
    }
  ]
}
```
